(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const ui = {
    loading: $("loading"),
    loadingText: $("loadingText"),
    hud: $("hud"),
    menu: $("menu"),
    garage: $("garage"),
    complete: $("levelComplete"),
    crash: $("crashScreen"),
    pause: $("pauseScreen"),
    error: $("errorBox"),
    errorMessage: $("errorMessage"),
    level: $("levelText"),
    coins: $("coinText"),
    distance: $("distanceText"),
    progress: $("progressBar"),
    speed: $("speedText"),
    menuLevel: $("menuLevel"),
    menuCoins: $("menuCoins"),
    bikeCount: $("bikeCount"),
    garageCoins: $("garageCoins"),
    bikeGrid: $("bikeGrid"),
    selectedBikeName: $("selectedBikeName"),
    selectedBikePrice: $("selectedBikePrice"),
    bikeAction: $("bikeActionBtn")
  };

  const SAVE_KEY = "motoRush3D_save_v2";
  const LEVEL_LENGTH = 1200;
  const LANES = [-2.5, 0, 2.5];

  const themes = [
    { name: "DESERT HIGHWAY", sky: 0x8cc7ed, ground: 0xbca06d, road: 0x34383d, prop: 0xc9a26d },
    { name: "GREEN VALLEY", sky: 0x8bd8ff, ground: 0x4d9b54, road: 0x30383a, prop: 0x2e7139 },
    { name: "DARK NIGHT", sky: 0x10192e, ground: 0x202735, road: 0x24272d, prop: 0x34445b },
    { name: "SNOW ROAD", sky: 0xc7e4f2, ground: 0xe5edf1, road: 0x515b65, prop: 0xb8d4e0 },
    { name: "SUNSET CITY", sky: 0xffa16e, ground: 0x66555c, road: 0x32323c, prop: 0x8b5864 },
    { name: "NEON HIGHWAY", sky: 0x171633, ground: 0x252344, road: 0x191b2c, prop: 0x5144a1 },
    { name: "MOUNTAIN PASS", sky: 0x9cb9d0, ground: 0x63746a, road: 0x34393b, prop: 0x68796d },
    { name: "COASTAL ROAD", sky: 0x75d3e9, ground: 0xd9c9a0, road: 0x343a40, prop: 0x4b9b9a }
  ];

  const bikeNames = [
    "STARTER", "STREET 125", "CITY RIDER", "ROADSTER", "SPEED X",
    "RACING 250", "FALCON", "THUNDER", "NIGHT RIDER", "VIPER",
    "BLAZE", "STORM", "PHANTOM", "BOLT", "TURBO",
    "SHADOW", "RAPTOR", "FURY", "HUNTER", "CYCLONE",
    "NITRO", "PANTHER", "FIREBIRD", "WILDFIRE", "SPECTRE",
    "TRACK PRO", "VENOM", "BANDIT", "TITAN", "HURRICANE",
    "ECLIPSE", "BLACKOUT", "REDLINE", "APEX", "DRAGON",
    "VIPER GT", "FALCON R", "STREET KING", "RAPID", "COMET",
    "DARK STAR", "BURNOUT", "RACER Z", "RUSH GT", "TORNADO",
    "PHOENIX", "IRON HORSE", "SILVER ARROW", "BLADE", "WARLOCK",
    "HYPER X", "SUPERSPORT", "NOVA", "QUANTUM", "INFERNO",
    "MIDNIGHT", "KING COBRA", "EXTREME", "RACE MASTER", "BLACK VIPER",
    "ULTRA SPORT", "RED PHANTOM", "GHOST X", "LEGEND", "DOMINATOR",
    "APOCALYPSE", "OMEGA", "TITANIUM", "GOLDEN RUSH", "DARK LEGEND",
    "HYPERBIKE", "ULTIMATE", "STREET DEMON", "VELOCITY", "SUPREME",
    "RUSH LEGEND", "INFINITY", "MOTO GOD"
  ];

  let save = loadSave();
  let selectedBike = save.selectedBike || 0;
  let previewBike = selectedBike;
  let scene, camera, renderer, clock;
  let player, playerModel;
  let road, ground;
  let roadMarks = [];
  let roadside = [];
  let vehicles = [];
  let pickups = [];
  let particles = [];
  let activeTheme = -1;

  let running = false;
  let paused = false;
  let crashed = false;
  let gameReady = false;
  let distance = 0;
  let gameSpeed = 28;
  let targetLane = 1;
  let playerX = 0;
  let spawnTimer = 0;
  let coinTimer = 0;
  let boostTime = 0;
  let brakeHeld = false;
  let boostHeld = false;
  let leftHeld = false;
  let rightHeld = false;
  let lastSavedCoins = save.coins;
  let music = null;
  let musicEnabled = false;
  let audioStarted = false;

  // --- GameMonetize Ad Helpers ---
  function showGameMonetizeAd() {
    if (typeof sdk !== 'undefined' && typeof sdk.showBanner !== 'undefined') {
      sdk.showBanner();
    }
  }

  window.pauseGameForAd = function() {
    paused = true;
    if (music && musicEnabled) music.pause();
  };

  window.resumeGameFromAd = function() {
    paused = false;
    if (music && musicEnabled && running) music.play().catch(() => {});
  };

  function loadSave() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        return {
          level: Math.max(1, Math.min(1000, Number(data.level) || 1)),
          coins: Math.max(0, Number(data.coins) || 0),
          selectedBike: Math.max(0, Math.min(79, Number(data.selectedBike) || 0)),
          unlocked: Array.isArray(data.unlocked)
            ? [...new Set([0, ...data.unlocked.filter(n => Number.isInteger(n) && n >= 0 && n < 80)])]
            : [0]
        };
      }
    } catch (e) {
      console.warn("Save could not be read:", e);
    }

    return { level: 1, coins: 0, selectedBike: 0, unlocked: [0] };
  }

  function saveGame() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(save));
    } catch (e) {
      console.warn("Progress could not be saved:", e);
    }
  }

  function showOnly(element) {
    [
      ui.menu, ui.garage, ui.complete, ui.crash,
      ui.pause, ui.error
    ].forEach(panel => panel.classList.add("hidden"));

    if (element) element.classList.remove("hidden");
  }

  function updateMenu() {
    ui.menuLevel.textContent = save.level;
    ui.menuCoins.textContent = save.coins;
    ui.coins.textContent = save.coins;
    ui.bikeCount.textContent = save.unlocked.length + "/80";
    ui.garageCoins.textContent = save.coins;
  }

  function reportError(message) {
    ui.loading.classList.add("hidden");
    ui.hud.classList.add("hidden");
    showOnly(ui.error);
    ui.errorMessage.textContent = String(message || "Unknown error");
  }

  function makeMaterial(color, roughness = 0.7, metalness = 0) {
    return new THREE.MeshStandardMaterial({
      color,
      roughness,
      metalness
    });
  }

  function addBox(parent, name, position, scale, material) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(scale[0], scale[1], scale[2]),
      material
    );
    mesh.name = name || "";
    mesh.position.set(position[0], position[1], position[2]);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  function addCylinder(parent, position, radiusTop, radiusBottom, height, material, segments = 12) {
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(radiusTop, radiusBottom, height, segments),
      material
    );
    mesh.position.set(position[0], position[1], position[2]);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  function createBike(index) {
    const group = new THREE.Group();
    const color = new THREE.Color().setHSL((index * 0.137 + 0.02) % 1, 0.85, 0.48);
    const paint = makeMaterial(color, 0.3, 0.4);
    const dark = makeMaterial(0x17191f, 0.55, 0.2);
    const rubber = makeMaterial(0x101114, 0.85);
    const metal = makeMaterial(0xaeb8c5, 0.3, 0.8);
    const glass = new THREE.MeshStandardMaterial({
      color: 0x8bd8ff,
      metalness: 0.65,
      roughness: 0.15,
      transparent: true,
      opacity: 0.75
    });
    const lamp = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xffffff,
      emissiveIntensity: 1.1
    });

    [-0.93, 0.88].forEach(z => {
      const wheel = new THREE.Mesh(
        new THREE.CylinderGeometry(0.36, 0.36, 0.16, 18),
        rubber
      );
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(0, 0.43, z);
      wheel.castShadow = true;
      group.add(wheel);

      const hub = new THREE.Mesh(
        new THREE.CylinderGeometry(0.13, 0.13, 0.18, 12),
        metal
      );
      hub.rotation.z = Math.PI / 2;
      hub.position.copy(wheel.position);
      group.add(hub);
    });

    addBox(group, "frame", [0, 0.83, 0], [0.35, 0.2, 1.25], dark);
    addBox(group, "tank", [0, 1.14, -0.12], [0.58, 0.43, 0.7], paint);
    addBox(group, "seat", [0, 1.16, 0.56], [0.42, 0.16, 0.52], dark);
    addBox(group, "frontFairing", [0, 1.23, -0.73], [0.52, 0.55, 0.36], paint);
    addBox(group, "windscreen", [0, 1.59, -0.78], [0.36, 0.35, 0.09], glass);
    addBox(group, "headlight", [0, 1.17, -0.925], [0.25, 0.17, 0.05], lamp);

    const fork1 = addCylinder(group, [-0.14, 0.85, -0.82], 0.045, 0.045, 0.75, metal);
    const fork2 = addCylinder(group, [0.14, 0.85, -0.82], 0.045, 0.045, 0.75, metal);
    fork1.rotation.x = 0.15;
    fork2.rotation.x = 0.15;

    const handle = addBox(group, "handlebar", [0, 1.48, -0.72], [0.95, 0.07, 0.08], metal);
    handle.rotation.z = 0.04;

    const suit = makeMaterial(0x252b3a, 0.75);
    const helmet = makeMaterial(0xf4f4f4, 0.3, 0.25);
    const visor = makeMaterial(0x1b2739, 0.15, 0.5);

    const body = addBox(group, "riderBody", [0, 1.75, 0.13], [0.46, 0.68, 0.34], suit);
    body.rotation.x = -0.25;

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.24, 16, 12),
      helmet
    );
    head.position.set(0, 2.18, -0.12);
    head.castShadow = true;
    group.add(head);

    addBox(group, "visor", [0, 2.19, -0.335], [0.29, 0.13, 0.055], visor);

    [-1, 1].forEach(side => {
      const arm = addBox(
        group,
        "arm",
        [side * 0.29, 1.64, -0.35],
        [0.15, 0.48, 0.17],
        suit
      );
      arm.rotation.x = -0.5;
      arm.rotation.z = side * 0.18;

      const leg = addBox(
        group,
        "leg",
        [side * 0.22, 1.1, 0.43],
        [0.17, 0.48, 0.18],
        dark
      );
      leg.rotation.x = 0.25;
    });

    group.scale.setScalar(index === 0 ? 1 : 1 + Math.min(index, 40) * 0.001);
    group.userData.bikeIndex = index;
    return group;
  }

  function createPlayer() {
    player = new THREE.Group();
    playerModel = createBike(selectedBike);
    player.add(playerModel);
    player.position.set(0, 0, 3.5);
    scene.add(player);
  }

  function createWorld() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x8cc7ed);
    scene.fog = new THREE.Fog(0x8cc7ed, 45, 230);

    camera = new THREE.PerspectiveCamera(
      62,
      window.innerWidth / window.innerHeight,
      0.1,
      500
    );
    camera.position.set(0, 4.5, 10.5);
    camera.lookAt(0, 1.1, -5);

    renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: "high-performance"
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    $("game").insertBefore(renderer.domElement, $("game").firstChild);

    const hemi = new THREE.HemisphereLight(0xdbeeff, 0x4c453c, 2.1);
    scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xffffff, 2.6);
    sun.position.set(-10, 22, 10);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -18;
    sun.shadow.camera.right = 18;
    sun.shadow.camera.top = 25;
    sun.shadow.camera.bottom = -25;
    scene.add(sun);

    clock = new THREE.Clock();

    buildRoad();
    createPlayer();
    buildEnvironment(true);
  }

  function buildRoad() {
    const roadMat = makeMaterial(0x34383d, 0.95);
    const groundMat = makeMaterial(0x6b9658, 1);
    const edgeMat = makeMaterial(0xece8d8);
    const stripeMat = makeMaterial(0xf9f0d0);

    road = new THREE.Mesh(new THREE.PlaneGeometry(10, 500), roadMat);
    road.rotation.x = -Math.PI / 2;
    road.position.set(0, -0.05, -110);
    road.receiveShadow = true;
    scene.add(road);

    ground = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, -0.14, -110);
    ground.receiveShadow = true;
    scene.add(ground);

    [-4.75, 4.75].forEach(x => {
      const edge = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.025, 500), edgeMat);
      edge.position.set(x, 0.005, -110);
      scene.add(edge);
    });

    roadMarks = [];

    [-1.25, 1.25].forEach(x => {
      for (let i = 0; i < 30; i++) {
        const mark = new THREE.Mesh(
          new THREE.BoxGeometry(0.075, 0.025, 2.6),
          stripeMat
        );
        mark.position.set(x, 0.01, -190 + i * 7);
        scene.add(mark);
        roadMarks.push(mark);
      }
    });
  }

  function clearGroupObjects(list) {
    list.forEach(object => {
      scene.remove(object);
      disposeObject(object);
    });
    list.length = 0;
  }

  function disposeObject(object) {
    object.traverse(child => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach(m => m.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
  }

  function buildEnvironment(changeTheme) {
    const themeIndex = (save.level - 1) % themes.length;
    const theme = themes[themeIndex];
    activeTheme = themeIndex;

    scene.background.setHex(theme.sky);
    scene.fog.color.setHex(theme.sky);
    ground.material.color.setHex(theme.ground);
    road.material.color.setHex(theme.road);

    if (!changeTheme) return;

    clearGroupObjects(roadside);

    const rng = mulberry32(save.level * 92821 + 73);

    for (let side of [-1, 1]) {
      for (let i = 0; i < 26; i++) {
        const z = -195 + i * 8.5;
        const x = side * (7 + rng() * 13);
        const type = (save.level + i + Math.floor(rng() * 8)) % 4;
        let object;

        if (themeIndex === 2 || themeIndex === 5) {
          const buildingMat = makeMaterial(
            type % 2 ? 0x33304e : 0x343e56,
            0.85
          );
          object = addBox(
            scene,
            "cityBuilding",
            [x, 1.8 + rng() * 2, z],
            [2.2 + rng() * 3, 4 + rng() * 7, 2 + rng() * 3],
            buildingMat
          );
          object.userData.baseY = object.position.y;
        } else if (themeIndex === 0) {
          const trunk = addCylinder(
            scene, [x, 1.1, z], 0.12, 0.19, 2.2,
            makeMaterial(0x775033)
          );
          const crown = new THREE.Mesh(
            new THREE.ConeGeometry(1.15, 2.8, 7),
            makeMaterial(0x4c8c45)
          );
          crown.position.set(x, 3.0, z);
          crown.castShadow = true;
          scene.add(crown);
          object = new THREE.Group();
          object.add(trunk);
          object.add(crown);
          object.position.set(0, 0, 0);
        } else if (type === 0 || type === 1) {
          const trunk = addCylinder(
            scene, [x, 0.75, z], 0.12, 0.17, 1.5,
            makeMaterial(0x6c4b32)
          );
          const crown = new THREE.Mesh(
            new THREE.SphereGeometry(1.0 + rng() * 0.6, 8, 7),
            makeMaterial(theme.prop)
          );
          crown.position.set(x, 1.9, z);
          crown.castShadow = true;
          scene.add(crown);
          object = new THREE.Group();
          object.add(trunk);
          object.add(crown);
        } else {
          object = addBox(
            scene,
            "roadsideRock",
            [x, 0.45, z],
            [1.2 + rng(), 0.8 + rng(), 1.1 + rng()],
            makeMaterial(theme.prop)
          );
        }

        object.userData.roadside = true;
        object.userData.side = side;
        object.userData.startX = x;
        object.userData.baseZ = z;
        roadside.push(object);
      }
    }

    const stripeColors = [0xf5e4c2, 0xefffe6, 0x8a8bff, 0xffffff];
    const color = stripeColors[themeIndex % stripeColors.length];

    roadMarks.forEach(mark => mark.material.color.setHex(color));
  }

  function mulberry32(seed) {
    return function () {
      let t = seed += 0x6D2B79F5;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function createTrafficVehicle() {
    const lane = Math.floor(Math.random() * 3);
    const roll = Math.random();
    let type = "car";

    if (roll > 0.84) type = "truck";
    else if (roll > 0.68) type = "van";
    else if (roll > 0.56) type = "heavyTruck";

    const group = new THREE.Group();
    const colors = [0xe84242, 0x297bd1, 0xf2c230, 0xf0f0f0, 0x353b47, 0x28a47d];
    const color = colors[Math.floor(Math.random() * colors.length)];
    const bodyMat = makeMaterial(color, 0.35, 0.25);
    const glassMat = makeMaterial(0x8cb9d5, 0.18, 0.2);
    const tireMat = makeMaterial(0x111111, 0.9);
    const lightMat = makeMaterial(0xfff0bf, 0.2, 0.2);

    let width = 1.5;
    let length = 2.5;
    let height = 1.05;

    if (type === "van") {
      width = 1.65;
      length = 3.1;
      height = 1.55;
    } else if (type === "truck") {
      width = 1.9;
      length = 4.8;
      height = 2.0;
    } else if (type === "heavyTruck") {
      width = 2.15;
      length = 6.1;
      height = 2.5;
    }

    addBox(group, "vehicleBody", [0, height * 0.65, 0], [width, height, length], bodyMat);

    if (type === "car") {
      addBox(group, "carCabin", [0, height + 0.22, -0.18], [width * 0.78, 0.55, length * 0.52], glassMat);
    } else if (type === "van") {
      addBox(group, "vanCabin", [0, height + 0.14, -0.3], [width * 0.83, 0.55, length * 0.82], glassMat);
    } else {
      const cargoColor = type === "truck" ? 0xe5e5e5 : 0xd6dce4;
      addBox(
        group,
        "cargoBox",
        [0, height + 0.5, 0.55],
        [width * 0.94, type === "truck" ? 1.2 : 1.7, length * 0.64],
        makeMaterial(cargoColor)
      );
      addBox(
        group,
        "truckCabin",
        [0, height + 0.25, -length * 0.35],
        [width * 0.92, 0.9, length * 0.27],
        bodyMat
      );
      addBox(
        group,
        "truckWindow",
        [0, height + 0.52, -length * 0.49],
        [width * 0.67, 0.37, 0.045],
        glassMat
      );
    }

    const wheelPositions = [
      [-width * 0.52, 0.35, -length * 0.32],
      [width * 0.52, 0.35, -length * 0.32],
      [-width * 0.52, 0.35, length * 0.32],
      [width * 0.52, 0.35, length * 0.32]
    ];

    if (type === "truck" || type === "heavyTruck") {
      wheelPositions.push(
        [-width * 0.52, 0.35, 0.15],
        [width * 0.52, 0.35, 0.15]
      );
    }

    wheelPositions.forEach(pos => {
      const wheel = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.3, 0.16, 10),
        tireMat
      );
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(pos[0], pos[1], pos[2]);
      group.add(wheel);
    });

    [-0.45, 0.45].forEach(x => {
      const headlight = new THREE.Mesh(
        new THREE.BoxGeometry(0.25, 0.12, 0.07),
        lightMat
      );
      headlight.position.set(x * (width / 1.5), 0.62, -length / 2 - 0.035);
      group.add(headlight);
    });

    group.position.set(LANES[lane], 0, -115);
    group.userData = {
      lane,
      type,
      width,
      length,
      speed: 0.72 + Math.random() * 0.65
    };

    scene.add(group);
    vehicles.push(group);
  }

  function createCoin() {
    const lane = Math.floor(Math.random() * 3);
    const coinMat = new THREE.MeshStandardMaterial({
      color: 0xffd229,
      metalness: 0.8,
      roughness: 0.2,
      emissive: 0x6d4700,
      emissiveIntensity: 0.35
    });

    const coin = new THREE.Mesh(
      new THREE.CylinderGeometry(0.38, 0.38, 0.12, 20),
      coinMat
    );
    coin.rotation.x = Math.PI / 2;
    coin.position.set(LANES[lane], 1.0, -110);
    coin.castShadow = true;
    coin.userData.spin = 2 + Math.random() * 2;
    scene.add(coin);
    pickups.push(coin);
  }

  function removeTraffic() {
    clearGroupObjects(vehicles);
    clearGroupObjects(pickups);
    clearGroupObjects(particles);
  }

  function refreshPlayerBike() {
    if (!player) return;

    if (playerModel) {
      player.remove(playerModel);
      disposeObject(playerModel);
    }

    playerModel = createBike(selectedBike);
    player.add(playerModel);
  }

  function startRace() {
    if (!gameReady) return;

    showOnly(null);
    ui.hud.classList.remove("hidden");
    ui.loading.classList.add("hidden");

    removeTraffic();
    distance = 0;
    targetLane = 1;
    playerX = 0;
    spawnTimer = 0.8;
    coinTimer = 1.4;
    boostTime = 0;
    gameSpeed = 28;
    brakeHeld = false;
    boostHeld = false;
    leftHeld = false;
    rightHeld = false;
    crashed = false;
    paused = false;
    running = true;

    player.position.set(0, 0, 3.5);
    player.rotation.set(0, 0, 0);
    refreshPlayerBike();
    buildEnvironment(true);
    updateHUD();
  }

  function updateHUD() {
    ui.level.textContent = save.level + " / 1000";
    ui.coins.textContent = save.coins;
    ui.distance.textContent = Math.floor(distance) + " m";
    ui.progress.style.width = Math.min(100, distance / LEVEL_LENGTH * 100) + "%";
    ui.speed.textContent = Math.round(gameSpeed * 4.2);
    updateMenu();
  }

  function addCoins(amount) {
    save.coins += amount;
    lastSavedCoins = save.coins;
    saveGame();
    updateHUD();
  }

  function winLevel() {
    if (!running) return;

    running = false;
    save.level = Math.min(1000, save.level + 1);
    const reward = 20 + Math.floor(Math.random() * 11);
    save.coins += reward;
    lastSavedCoins = save.coins;
    saveGame();
    updateHUD();

    $("rewardCoins").textContent = reward;
    $("nextLevelText").textContent =
      save.level === 1000
        ? "NEXT LEVEL READY!"
        : "NEXT TRACK: " + themes[(save.level - 1) % themes.length].name;

    showOnly(ui.complete);
  }

  function crash() {
    if (!running) return;

    running = false;
    crashed = true;
    saveGame();
    showOnly(ui.crash);
  }

  function setLane(direction) {
    if (!running || paused) return;
    targetLane = Math.max(0, Math.min(2, targetLane + direction));
  }

  function moveWorld(delta) {
    const movement = gameSpeed * delta;

    roadMarks.forEach(mark => {
      mark.position.z += movement;
      if (mark.position.z > 8) mark.position.z -= 210;
    });

    roadside.forEach(object => {
      object.position.z += movement;
      if (object.position.z > 25) {
        object.position.z -= 220;
      }
    });

    vehicles.forEach(vehicle => {
      const relativeSpeed = gameSpeed * vehicle.userData.speed;
      vehicle.position.z += relativeSpeed * delta;
    });

    pickups.forEach(coin => {
      coin.position.z += movement;
      coin.rotation.y += coin.userData.spin * delta;
      coin.position.y = 1.0 + Math.sin(performance.now() * 0.003 + coin.position.z) * 0.12;
    });
  }

  function checkCollisions() {
    for (let i = vehicles.length - 1; i >= 0; i--) {
      const vehicle = vehicles[i];

      if (vehicle.position.z > 15) {
        scene.remove(vehicle);
        disposeObject(vehicle);
        vehicles.splice(i, 1);
        continue;
      }

      const dx = Math.abs(vehicle.position.x - player.position.x);
      const dz = Math.abs(vehicle.position.z - player.position.z);

      if (dx < 1.3 && dz < 2.8) {
        crash();
        return;
      }
    }

    for (let i = pickups.length - 1; i >= 0; i--) {
      const coin = pickups[i];

      if (coin.position.z > 12) {
        scene.remove(coin);
        disposeObject(coin);
        pickups.splice(i, 1);
        continue;
      }

      const dx = Math.abs(coin.position.x - player.position.x);
      const dz = Math.abs(coin.position.z - player.position.z);

      if (dx < 1.2 && dz < 2.0) {
        scene.remove(coin);
        disposeObject(coin);
        pickups.splice(i, 1);
        addCoins(1);
      }
    }
  }

  function updateGame(delta) {
    if (!running || paused) return;

    delta = Math.min(delta, 0.05);

    if (leftHeld) setLane(-1);
    if (rightHeld) setLane(1);

    leftHeld = false;
    rightHeld = false;

    if (brakeHeld) {
      gameSpeed = Math.max(13, gameSpeed - 24 * delta);
    } else {
      const baseSpeed = boostHeld ? 48 : 28;
      gameSpeed += (baseSpeed - gameSpeed) * Math.min(1, delta * 1.8);
    }

    if (boostTime > 0) {
      boostTime -= delta;
      gameSpeed = Math.min(56, gameSpeed + 10 * delta);
    }

    distance += gameSpeed * delta;
    moveWorld(delta);

    const laneX = LANES[targetLane];
    playerX += (laneX - playerX) * Math.min(1, delta * 8);
    player.position.x = playerX;

    if (playerModel) {
      playerModel.rotation.z = (laneX - playerX) * -0.12;
    }

    const desiredCameraX = player.position.x * 0.72;
    camera.position.x += (desiredCameraX - camera.position.x) * Math.min(1, delta * 3.5);
    camera.position.y += (4.5 - camera.position.y) * Math.min(1, delta * 2);
    camera.position.z += (10.5 - camera.position.z) * Math.min(1, delta * 2.5);
    camera.lookAt(player.position.x * 0.45, 1.15, -5.5);

    spawnTimer -= delta;
    coinTimer -= delta;

    if (spawnTimer <= 0) {
      createTrafficVehicle();
      spawnTimer = Math.max(0.62, 1.35 - save.level * 0.00035) + Math.random() * 0.6;
    }

    if (coinTimer <= 0) {
      createCoin();
      coinTimer = 1.4 + Math.random() * 1.6;
    }

    checkCollisions();

    if (distance >= LEVEL_LENGTH) {
      winLevel();
    }

    updateHUD();
  }

  function animate() {
    requestAnimationFrame(animate);

    if (!renderer || !scene || !camera) return;

    const delta = clock ? clock.getDelta() : 0.016;

    try {
      updateGame(delta);
      renderer.render(scene, camera);
    } catch (error) {
      console.error(error);
      running = false;
      reportError(error.message || error);
    }
  }

  function openGarage() {
    previewBike = selectedBike;
    renderGarage();
    showOnly(ui.garage);
  }

  function renderGarage() {
    ui.garageCoins.textContent = save.coins;
    ui.bikeGrid.innerHTML = "";

    bikeNames.forEach((name, index) => {
      const unlocked = save.unlocked.includes(index);
      const price = bikePrice(index);
      const card = document.createElement("button");

      card.className = "bike-card" + (previewBike === index ? " selected" : "");
      card.type = "button";

      card.innerHTML =
        '<span class="bike-emoji">🏍️</span>' +
        "<strong>" + name + "</strong>" +
        "<span>" + (unlocked ? "OWNED" : price + " COINS") + "</span>";

      card.addEventListener("click", () => {
        previewBike = index;
        renderGarage();
      });

      ui.bikeGrid.appendChild(card);
    });

    ui.selectedBikeName.textContent = bikeNames[previewBike];
    const price = bikePrice(previewBike);
    const unlocked = save.unlocked.includes(previewBike);

    ui.selectedBikePrice.textContent = unlocked ? "OWNED" : price + " COINS";
    ui.bikeAction.textContent = unlocked
      ? (selectedBike === previewBike ? "SELECTED" : "SELECT")
      : "BUY BIKE";

    ui.bikeAction.disabled = unlocked && selectedBike === previewBike;
    ui.bikeAction.style.opacity = ui.bikeAction.disabled ? "0.55" : "1";
  }

  function bikePrice(index) {
    if (index === 0) return 0;
    return Math.round(100 + index * 75 + Math.pow(index, 1.55) * 18);
  }

  function bikeAction() {
    const index = previewBike;
    const price = bikePrice(index);

    if (save.unlocked.includes(index)) {
      selectedBike = index;
      save.selectedBike = index;
      saveGame();
      refreshPlayerBike();
      renderGarage();
      updateMenu();
      return;
    }

    if (save.coins < price) {
      ui.selectedBikePrice.textContent = "NOT ENOUGH COINS";
      return;
    }

    save.coins -= price;
    save.unlocked.push(index);
    selectedBike = index;
    save.selectedBike = index;
    saveGame();

    refreshPlayerBike();
    renderGarage();
    updateMenu();
  }

  function startMusic() {
    if (!music) {
      music = new Audio(
        "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      );
      music.loop = true;
      music.volume = 0.25;
    }

    if (!musicEnabled) {
      musicEnabled = true;
      music.play().then(() => {
        audioStarted = true;
        $("musicBtn").textContent = "♫ MUSIC ON";
      }).catch(() => {
        musicEnabled = false;
        $("musicBtn").textContent = "♫ TAP MUSIC";
      });
    } else {
      music.pause();
      musicEnabled = false;
      $("musicBtn").textContent = "♫ MUSIC";
    }
  }

  function togglePause() {
    if (!running && !paused) return;

    if (paused) {
      paused = false;
      showOnly(null);
      ui.hud.classList.remove("hidden");
      if (music && musicEnabled) music.play().catch(() => {});
    } else {
      paused = true;
      showOnly(ui.pause);
      if (music) music.pause();
    }
  }

  function bindHoldButton(id, callback) {
    const button = $(id);
    if (!button) return;
    button.addEventListener("pointerdown", event => {
      event.preventDefault();
      callback(true);
      try {
        button.setPointerCapture(event.pointerId);
      } catch (_) {}
    });

    const release = event => {
      if (event) event.preventDefault();
      callback(false);
    };

    button.addEventListener("pointerup", release);
    button.addEventListener("pointercancel", release);
    button.addEventListener("lostpointercapture", release);
    button.addEventListener("contextmenu", event => event.preventDefault());
  }

  function bindControls() {
    $("leftBtn").addEventListener("click", () => setLane(-1));
    $("rightBtn").addEventListener("click", () => setLane(1));

    bindHoldButton("brakeBtn", value => {
      brakeHeld = value;
    });

    bindHoldButton("boostBtn", value => {
      boostHeld = value;
    });

    window.addEventListener("keydown", event => {
      if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", " "].includes(event.key)) {
        event.preventDefault();
      }

      if (event.repeat && ["ArrowLeft", "ArrowRight", "a", "A", "d", "D"].includes(event.key)) {
        return;
      }

      if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") {
        setLane(-1);
      }

      if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") {
        setLane(1);
      }

      if (event.key === "ArrowDown" || event.key.toLowerCase() === "s") {
        brakeHeld = true;
      }

      if (event.key === "ArrowUp" || event.key.toLowerCase() === "w") {
        boostHeld = true;
      }

      if (event.key === "Escape" || event.key === "p") {
        togglePause();
      }
    });

    window.addEventListener("keyup", event => {
      if (event.key === "ArrowDown" || event.key.toLowerCase() === "s") {
        brakeHeld = false;
      }

      if (event.key === "ArrowUp" || event.key.toLowerCase() === "w") {
        boostHeld = false;
      }
    });

    window.addEventListener("blur", () => {
      brakeHeld = false;
      boostHeld = false;
    });

    $("playBtn").addEventListener("click", startRace);

    $("retryBtn").addEventListener("click", () => {
      startRace();
      showGameMonetizeAd();
    });

    $("nextLevelBtn").addEventListener("click", () => {
      if (save.level > 1000) save.level = 1000;
      startRace();
      showGameMonetizeAd();
    });

    $("garageBtn").addEventListener("click", openGarage);
    $("menuGarageBtn").addEventListener("click", openGarage);
    $("completeGarageBtn").addEventListener("click", openGarage);

    $("closeGarage").addEventListener("click", () => {
      if (running) {
        showOnly(null);
        ui.hud.classList.remove("hidden");
      } else {
        showOnly(ui.menu);
      }
    });

    ui.bikeAction.addEventListener("click", bikeAction);

    $("pauseBtn").addEventListener("click", togglePause);
    $("resumeBtn").addEventListener("click", togglePause);

    $("pauseMenuBtn").addEventListener("click", () => {
      paused = false;
      running = false;
      if (music) music.pause();
      ui.hud.classList.add("hidden");
      showOnly(ui.menu);
      updateMenu();
    });

    $("crashMenuBtn").addEventListener("click", () => {
      running = false;
      crashed = false;
      ui.hud.classList.add("hidden");
      showOnly(ui.menu);
      updateMenu();
    });

    $("musicBtn").addEventListener("click", startMusic);

    $("resetBtn").addEventListener("click", () => {
      const confirmed = window.confirm("Are you sure you want to reset all progress and coins?");
      if (!confirmed) return;

      save = {
        level: 1,
        coins: 0,
        selectedBike: 0,
        unlocked: [0]
      };
      selectedBike = 0;
      previewBike = 0;
      saveGame();
      updateMenu();
      refreshPlayerBike();
      buildEnvironment(true);
    });

    $("closeErrorBtn").addEventListener("click", () => {
      ui.error.classList.add("hidden");
      ui.menu.classList.remove("hidden");
    });

    window.addEventListener("resize", resizeGame);

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") {
        saveGame();
        if (music) music.pause();
      }
    });

    window.addEventListener("pagehide", saveGame);
  }

  function resizeGame() {
    if (!renderer || !camera) return;

    const width = window.innerWidth;
    const height = window.innerHeight;

    camera.aspect = width / height;
    camera.fov = width > height ? 58 : 65;
    camera.updateProjectionMatrix();

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
  }

  function init() {
    try {
      if (!window.THREE) {
        throw new Error(
          "Three.js Library is missing. Check your network or HTML link."
        );
      }

      ui.loadingText.textContent = "Preparing road and bike...";
      createWorld();
      bindControls();
      updateMenu();
      renderGarage();

      gameReady = true;
      ui.loading.classList.add("hidden");
      ui.hud.classList.add("hidden");
      showOnly(ui.menu);

      animate();
    } catch (error) {
      console.error(error);
      reportError(error.message || error);
    }
  }

  init();
})();