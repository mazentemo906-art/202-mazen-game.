(async function loadThreeAndStart() {
  function loadScript(url) {
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = url;
      script.onload = resolve;
      script.onerror = () => {
        script.remove();
        reject(new Error("Failed to load " + url));
      };
      document.head.appendChild(script);
    });
  }

  try {
    if (!window.THREE) {
      try {
        await loadScript(
          "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"
        );
      } catch (firstError) {
        if (!window.THREE) {
          await loadScript(
            "https://cdnjs.cloudflare.com/ajax/libs/three.js/0.160.0/three.min.js"
          );
        }
      }
    }

    if (!window.THREE) {
      throw new Error("Three.js did not create window.THREE");
    }

    initGame();
  } catch (error) {
    console.error(error);
    const loading = document.getElementById("loading");
    if (loading) {
      loading.style.display = "grid";
      loading.textContent =
        "THREE.JS FAILED TO LOAD. CHECK YOUR INTERNET CONNECTION AND TRY AGAIN.";
    }
  }
})();

function initGame() {
  const $ = id => document.getElementById(id);

  const game = $("game");
  const loading = $("loading");
  const menu = $("menu");
  const garage = $("garage");
  const result = $("result");

  // ---------------- SAVE DATA ----------------

  const SAVE_KEY = "motoRush_v3";

  function loadSave() {
    try {
      const s = JSON.parse(localStorage.getItem(SAVE_KEY));

      if (s) {
        return {
          unlocked: THREE.MathUtils.clamp(
            Number(s.unlocked) || 1, 1, 1000
          ),
          coins: Math.max(0, Number(s.coins) || 0),
          owned: Array.isArray(s.owned)
            ? [...new Set([0, ...s.owned.filter(
                n => Number.isInteger(n) && n >= 0 && n < 80
              )])]
            : [0],
          selected: THREE.MathUtils.clamp(
            Number(s.selected) || 0, 0, 79
          )
        };
      }
    } catch (e) {
      console.warn("Save data could not be read.", e);
    }

    return { unlocked: 1, coins: 0, owned: [0], selected: 0 };
  }

  let save = loadSave();

  if (!save.owned.includes(save.selected)) save.selected = 0;

  let level = save.unlocked;
  let totalCoins = save.coins;
  let runCoins = 0;
  let distance = 0;
  let speed = 0;
  let targetSpeed = 0;
  let steer = 0;
  let running = false;
  let crashed = false;
  let muted = false;
  let musicEnabled = true;
  let currentMap = 0;
  let lastTime = 0;
  let spawnTimer = 0;
  let coinTimer = 0;
  let toastTimer = null;
  let lastBrakeSound = 0;
  let laneOffset = 0;

  function saveGame() {
    try {
      save.coins = totalCoins;
      localStorage.setItem(SAVE_KEY, JSON.stringify(save));
    } catch (e) {
      console.warn("Saving is unavailable.", e);
    }
  }

  // ---------------- SIX WORLDS ----------------

  const maps = [
    {
      name: "GREEN MOUNTAINS",
      sky: 0x82c9ef,
      ground: 0x47753c,
      road: 0x33363b
    },
    {
      name: "DESERT CANYON",
      sky: 0xf3b66e,
      ground: 0xb67a42,
      road: 0x4b4039
    },
    {
      name: "NEON CITY",
      sky: 0x10102f,
      ground: 0x18182d,
      road: 0x252538
    },
    {
      name: "SNOW HIGHWAY",
      sky: 0xb7d8f0,
      ground: 0xe3edf2,
      road: 0x515d68
    },
    {
      name: "DARK FOREST",
      sky: 0x213b35,
      ground: 0x1d442c,
      road: 0x303c36
    },
    {
      name: "COASTAL ROAD",
      sky: 0x68bde9,
      ground: 0xceb87c,
      road: 0x454b50
    }
  ];

  // ---------------- AUDIO ----------------

  let audioCtx = null;
  let masterGain = null;
  let engineOsc = null;
  let engineGain = null;
  let musicGain = null;
  let musicTimer = null;
  let musicStep = 0;
  let audioReady = false;

  function initAudio() {
    if (audioReady) {
      if (audioCtx.state === "suspended") audioCtx.resume();
      return;
    }

    try {
      const AudioContextClass =
        window.AudioContext || window.webkitAudioContext;

      if (!AudioContextClass) return;

      audioCtx = new AudioContextClass();

      masterGain = audioCtx.createGain();
      masterGain.gain.value = muted ? 0 : 0.65;
      masterGain.connect(audioCtx.destination);

      engineGain = audioCtx.createGain();
      engineGain.gain.value = 0;
      engineGain.connect(masterGain);

      engineOsc = audioCtx.createOscillator();
      engineOsc.type = "sawtooth";
      engineOsc.frequency.value = 65;
      engineOsc.connect(engineGain);
      engineOsc.start();

      musicGain = audioCtx.createGain();
      musicGain.gain.value = 0.12;
      musicGain.connect(masterGain);

      audioReady = true;
      audioCtx.resume();

      updateEngineSound();

      if (musicEnabled) startMusic();
    } catch (error) {
      console.warn("Audio unavailable:", error);
    }
  }

  function tone(freq, duration, type = "sine", volume = 0.12, slide = 0) {
    if (!audioReady || muted || !audioCtx) return;

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const now = audioCtx.currentTime;

    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freq), now);

    if (slide) {
      osc.frequency.exponentialRampToValueAtTime(
        Math.max(20, freq + slide), now + duration
      );
    }

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(
      Math.max(0.001, volume), now + 0.015
    );
    gain.gain.exponentialRampToValueAtTime(
      0.0001, now + duration
    );

    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(now);
    osc.stop(now + duration + 0.03);
  }

  function noiseBurst(duration = 0.2, volume = 0.15) {
    if (!audioReady || muted) return;

    const length = Math.floor(audioCtx.sampleRate * duration);
    const buffer = audioCtx.createBuffer(1, length, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < length; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / length);
    }

    const source = audioCtx.createBufferSource();
    const filter = audioCtx.createBiquadFilter();
    const gain = audioCtx.createGain();

    source.buffer = buffer;
    filter.type = "lowpass";
    filter.frequency.value = 1500;
    gain.gain.value = volume;

    source.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);
    source.start();
  }

  function playCoinSound() {
    tone(880, 0.12, "sine", 0.16);
    setTimeout(() => tone(1320, 0.17, "sine", 0.12), 75);
  }

  function playBrakeSound() {
    noiseBurst(0.16, 0.12);
    tone(170, 0.15, "triangle", 0.06, -80);
  }

  function playCrashSound() {
    noiseBurst(0.45, 0.25);
    tone(95, 0.45, "sawtooth", 0.15, -60);
  }

  function playWinSound() {
    tone(523, 0.18, "triangle", 0.15);
    setTimeout(() => tone(659, 0.18, "triangle", 0.15), 150);
    setTimeout(() => tone(784, 0.32, "triangle", 0.17), 300);
  }

  function playLoseSound() {
    tone(280, 0.25, "triangle", 0.15, -90);
    setTimeout(() => tone(160, 0.4, "triangle", 0.12, -50), 200);
  }

  function updateEngineSound() {
    if (!audioReady) return;

    const active = running && !crashed;
    const desiredGain = active ? 0.035 + speed / 100 * 0.11 : 0;

    engineGain.gain.setTargetAtTime(
      desiredGain, audioCtx.currentTime, 0.12
    );

    engineOsc.frequency.setTargetAtTime(
      48 + speed * 2.6, audioCtx.currentTime, 0.08
    );
  }

  function startMusic() {
    if (!audioReady || !musicEnabled || musicTimer) return;

    const notes = [
      196, 247, 294, 247, 220, 262, 330, 262,
      196, 247, 294, 370, 330, 294, 247, 220
    ];

    musicStep = 0;

    musicTimer = setInterval(() => {
      if (!audioReady || !musicEnabled || muted) return;

      const note = notes[musicStep % notes.length];

      tone(note, 0.24, "triangle", 0.035);

      if (musicStep % 4 === 0) {
        tone(note / 2, 0.28, "sine", 0.035);
      }

      musicStep++;
    }, 260);
  }

  function stopMusic() {
    if (musicTimer) {
      clearInterval(musicTimer);
      musicTimer = null;
    }
  }

  function updateSoundButtons() {
    $("soundBtn").textContent = muted ? "🔇 SOUND OFF" : "🔊 SOUND ON";
    $("musicBtn").textContent = musicEnabled ? "♫ MUSIC ON" : "♫ MUSIC OFF";
  }

  $("soundBtn").addEventListener("click", () => {
    initAudio();
    muted = !muted;

    if (masterGain) {
      masterGain.gain.setTargetAtTime(
        muted ? 0 : 0.65, audioCtx.currentTime, 0.03
      );
    }

    updateSoundButtons();
  });

  $("musicBtn").addEventListener("click", () => {
    initAudio();
    musicEnabled = !musicEnabled;

    if (musicEnabled) startMusic();
    else stopMusic();

    updateSoundButtons();
  });

  // ---------------- THREE.JS SCENE ----------------

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(maps[0].sky);
  scene.fog = new THREE.Fog(maps[0].sky, 35, 190);

  const camera = new THREE.PerspectiveCamera(
    65, window.innerWidth / window.innerHeight, 0.1, 600
  );

  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    powerPreference: "high-performance"
  });

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = false;

  game.insertBefore(renderer.domElement, game.firstChild);

  scene.add(new THREE.HemisphereLight(0xcde7ff, 0x3a3a32, 2));

  const sun = new THREE.DirectionalLight(0xffffff, 2);
  sun.position.set(-15, 30, 12);
  scene.add(sun);

  // Keep road and scenery inside one group so maps can be rebuilt cleanly.
  const world = new THREE.Group();
  scene.add(world);

  const traffic = [];
  const collectibles = [];
  const scenery = [];

  const roadMat = new THREE.MeshStandardMaterial({
    color: maps[0].road,
    roughness: 0.95,
    side: THREE.DoubleSide
  });

  const groundMat = new THREE.MeshStandardMaterial({
    color: maps[0].ground,
    roughness: 1,
    side: THREE.DoubleSide
  });

  const lineMat = new THREE.MeshStandardMaterial({
    color: 0xf5f3df,
    roughness: 1,
    side: THREE.DoubleSide
  });

  const edgeMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.8,
    side: THREE.DoubleSide
  });

  const neonMat = new THREE.MeshStandardMaterial({
    color: 0x5bf6ff,
    emissive: 0x145d6a,
    side: THREE.DoubleSide
  });

  function box(parent, w, h, d, color, x, y, z) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(w, h, d),
      new THREE.MeshStandardMaterial({
        color, roughness: 0.75, metalness: 0.12
      })
    );

    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  }

  function cylinder(parent, r1, r2, h, color, x, y, z, segments = 12) {
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(r1, r2, h, segments),
      new THREE.MeshStandardMaterial({
        color, roughness: 0.65, metalness: 0.25
      })
    );

    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  }

  function sphere(parent, r, color, x, y, z) {
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(r, 14, 12),
      new THREE.MeshStandardMaterial({
        color, roughness: 0.6, metalness: 0.08
      })
    );

    mesh.position.set(x, y, z);
    parent.add(mesh);
    return mesh;
  }

  // Road curves are fixed in world space. Traffic and scenery use the same curve.
  function roadCenter(z) {
    return Math.sin(z * 0.009) * 3.1 +
           Math.sin(z * 0.0035) * 4.3;
  }

  function makeStrip(width, zStart, zEnd, material, segments = 120, offset = 0) {
    const positions = [];
    const indices = [];

    for (let i = 0; i <= segments; i++) {
      const z = zStart + (zEnd - zStart) * i / segments;
      const cx = roadCenter(z) + offset;

      positions.push(cx - width / 2, 0, z);
      positions.push(cx + width / 2, 0, z);

      if (i < segments) {
        const a = i * 2;
        indices.push(a, a + 1, a + 2);
        indices.push(a + 1, a + 3, a + 2);
      }
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute(
      "position", new THREE.Float32BufferAttribute(positions, 3)
    );
    geometry.setIndex(indices);
    geometry.computeVertexNormals();

    return new THREE.Mesh(geometry, material);
  }

  function clearTraffic() {
    for (const t of traffic) scene.remove(t.mesh);
    traffic.length = 0;

    for (const c of collectibles) scene.remove(c.mesh);
    collectibles.length = 0;
  }

  function createScenery() {
    scenery.length = 0;
    const map = maps[currentMap];

    for (let i = 0; i < 90; i++) {
      const z = -335 + Math.random() * 370;
      const side = Math.random() < 0.5 ? -1 : 1;
      const x = roadCenter(z) + side * (11 + Math.random() * 42);

      const group = new THREE.Group();
      group.position.set(x, 0, z);

      if (currentMap === 0 || currentMap === 4) {
        cylinder(group, 0.16, 0.27, 2.3, 0x60412b, 0, 1.1, 0);

        const green = currentMap === 4 ? 0x17452b : 0x23713b;
        sphere(group, 1 + Math.random(), green, 0, 2.6, 0);
        sphere(group, 0.75, green, 0.3, 3.3, 0);
      } else if (currentMap === 1) {
        const rock = box(
          group,
          2 + Math.random() * 5,
          4 + Math.random() * 10,
          3 + Math.random() * 5,
          0xa45e32, 0, 2, 0
        );
        rock.rotation.y = Math.random() * 2;
      } else if (currentMap === 2) {
        const h = 8 + Math.random() * 22;

        box(
          group, 5 + Math.random() * 6, h, 6,
          [0x292b57, 0x35254e, 0x202f47][i % 3],
          0, h / 2, 0
        );

        for (let w = 0; w < 5; w++) {
          box(
            group, 0.3, 0.45, 0.08,
            i % 2 ? 0xff36d5 : 0x35f1ff,
            (Math.random() - 0.5) * 3,
            1.5 + Math.random() * h * 0.7,
            3
          );
        }
      } else if (currentMap === 3) {
        sphere(group, 3 + Math.random() * 4, 0xdbe8f0, 0, 1.2, 0);
      } else {
        cylinder(group, 0.12, 0.25, 3.4, 0x735334, 0, 1.7, 0);

        for (let k = 0; k < 5; k++) {
          const leaf = box(
            group, 0.25, 0.08, 2.5, 0x28764b, 0, 3.25, 0
          );
          leaf.rotation.y = k * Math.PI * 2 / 5;
          leaf.rotation.x = -0.25;
        }
      }

      world.add(group);
      scenery.push({ group, z, side });
    }
  }

  function buildRoad() {
    world.clear();
    scenery.length = 0;

    // Large flat terrain underneath the entire road.
    const terrain = new THREE.Mesh(
      new THREE.PlaneGeometry(500, 900),
      groundMat
    );

    terrain.rotation.x = -Math.PI / 2;
    terrain.position.set(0, -0.18, -145);
    world.add(terrain);

    const road = makeStrip(12, -350, 55, roadMat, 180);
    road.position.y = 0.01;
    world.add(road);

    for (const side of [-1, 1]) {
      const edge = makeStrip(
        0.22, -350, 55, edgeMat, 180, side * 6
      );
      edge.position.y = 0.035;
      world.add(edge);
    }

    for (const laneX of [-2, 2]) {
      for (let z = -345; z < 50; z += 12) {
        const dash = makeStrip(
          0.11, z, z + 5, currentMap === 2 ? neonMat : lineMat, 3, laneX
        );
        dash.position.y = 0.04;
        world.add(dash);
      }
    }

    createScenery();
  }

  let cityLight = null;

  function applyMap(index) {
    currentMap = ((index % maps.length) + maps.length) % maps.length;
    const map = maps[currentMap];

    scene.background = new THREE.Color(map.sky);
    scene.fog.color.setHex(map.sky);
    groundMat.color.setHex(map.ground);
    roadMat.color.setHex(map.road);

    $("mapLabel").textContent = map.name;

    if (cityLight) {
      scene.remove(cityLight);
      cityLight = null;
    }

    if (currentMap === 2) {
      sun.intensity = 0.45;
      cityLight = new THREE.AmbientLight(0x6655cc, 0.8);
      scene.add(cityLight);
    } else {
      sun.intensity = 2;
    }

    buildRoad();
  }

  // ---------------- PLAYER MOTORCYCLE ----------------

  const bike = new THREE.Group();
  scene.add(bike);

  let bikePaint = 0xff361e;

  function buildBike() {
    bike.clear();

    const paint = new THREE.MeshStandardMaterial({
      color: bikePaint,
      metalness: 0.55,
      roughness: 0.28
    });

    const black = new THREE.MeshStandardMaterial({
      color: 0x15181d, roughness: 0.75
    });

    const metal = new THREE.MeshStandardMaterial({
      color: 0xaab4bd, metalness: 0.85, roughness: 0.22
    });

    const rubber = new THREE.MeshStandardMaterial({
      color: 0x101216, roughness: 0.95
    });

    // Wheels, rims, hubs and spokes.
    for (const z of [-1.0, 1.05]) {
      const tire = new THREE.Mesh(
        new THREE.TorusGeometry(0.43, 0.125, 10, 24),
        rubber
      );
      tire.rotation.y = Math.PI / 2;
      tire.position.set(0, 0.48, z);
      bike.add(tire);

      const rim = new THREE.Mesh(
        new THREE.TorusGeometry(0.29, 0.035, 7, 18),
        metal
      );
      rim.rotation.y = Math.PI / 2;
      rim.position.set(0, 0.48, z);
      bike.add(rim);

      const hub = cylinder(
        bike, 0.12, 0.12, 0.25, metal, 0, 0.48, z
      );
      hub.rotation.z = Math.PI / 2;

      for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 4;
        const spoke = cylinder(
          bike, 0.018, 0.018, 0.53, 0xc0c7cc,
          0, 0.48, z, 5
        );
        spoke.rotation.z = a;
        spoke.rotation.x = Math.PI / 2;
      }
    }

    // Chassis and engine.
    box(bike, 0.38, 0.42, 0.85, black, 0, 0.85, 0.1);
    box(bike, 0.43, 0.32, 0.52, metal, 0, 0.78, 0.15);
    box(bike, 0.54, 0.12, 0.48, black, 0, 1.23, 0.38);
    box(bike, 0.5, 0.38, 0.62, paint, 0, 1.22, -0.08);

    // Sport fairings.
    const leftFairing = box(
      bike, 0.15, 0.48, 0.65, paint, -0.28, 1.0, -0.43
    );
    leftFairing.rotation.x = -0.15;

    const rightFairing = box(
      bike, 0.15, 0.48, 0.65, paint, 0.28, 1.0, -0.43
    );
    rightFairing.rotation.x = -0.15;

    // Forks and front fender.
    for (const x of [-0.16, 0.16]) {
      const fork = cylinder(
        bike, 0.045, 0.055, 0.85, metal, x, 0.85, -0.8
      );
      fork.rotation.x = -0.18;
    }

    box(bike, 0.52, 0.13, 0.58, paint, 0, 0.87, -0.97);
    box(bike, 0.9, 0.07, 0.1, metal, 0, 1.39, -0.72);

    // Mirrors.
    for (const x of [-0.48, 0.48]) {
      const stem = cylinder(
        bike, 0.025, 0.025, 0.28, metal, x, 1.54, -0.67
      );
      stem.rotation.z = x < 0 ? -0.25 : 0.25;
      sphere(bike, 0.09, black, x * 1.08, 1.69, -0.68);
    }

    // Headlight.
    const lampMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xe8f7ff,
      emissiveIntensity: 1.6
    });

    box(bike, 0.28, 0.18, 0.09, lampMat, 0, 1.22, -0.83);

    // Exhaust.
    const exhaust = cylinder(
      bike, 0.09, 0.12, 0.8, metal, 0.32, 0.7, 0.55
    );
    exhaust.rotation.x = Math.PI / 2;

    // Rider's body.
    const riderMat = new THREE.MeshStandardMaterial({
      color: 0x202936, roughness: 0.8
    });

    const torso = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.25, 0.58, 4, 8),
      riderMat
    );
    torso.position.set(0, 1.75, 0.12);
    torso.rotation.x = -0.4;
    bike.add(torso);

    // Rider arms.
    for (const side of [-1, 1]) {
      const arm = cylinder(
        bike, 0.075, 0.09, 0.68, 0x222b39,
        side * 0.24, 1.56, -0.32
      );
      arm.rotation.x = Math.PI / 2 - 0.3;
      arm.rotation.z = side * -0.25;

      // Boots and legs.
      const leg = cylinder(
        bike, 0.09, 0.12, 0.55, 0x11151b,
        side * 0.19, 1.0, 0.43
      );
      leg.rotation.x = -0.55;

      box(
        bike, 0.16, 0.12, 0.27, black,
        side * 0.19, 0.72, 0.26
      );
    }

    // Helmet and visor.
    sphere(bike, 0.3, 0xff5a19, 0, 2.29, -0.16);
    box(bike, 0.37, 0.13, 0.16, 0x111c2b, 0, 2.3, -0.4);
    box(bike, 0.06, 0.34, 0.08, 0xffffff, 0, 2.3, -0.19);

    bike.position.set(roadCenter(4), 0, 4);
  }

  buildBike();

  // ---------------- TRAFFIC ----------------

  function createVehicle(type, lane, z) {
    const group = new THREE.Group();

    const colors = [
      0x2196f3, 0xe53935, 0xffc107,
      0xeeeeee, 0x43a047, 0x8e44ad
    ];

    const color = colors[Math.floor(Math.random() * colors.length)];

    let width = 1.65;
    let height = 1.35;
    let length = 2.9;

    if (type === "truck") {
      width = 2.25;
      height = 2.7;
      length = 5.2;
    }

    if (type === "van") {
      width = 1.9;
      height = 2;
      length = 3.7;
    }

    box(group, width, height * 0.55, length, color, 0, height * 0.4, 0);

    box(
      group,
      width * 0.83,
      height * 0.32,
      length * 0.34,
      0x9bd6ef,
      0,
      height * 0.83,
      -length * 0.12
    );

    if (type === "truck") {
      box(group, width, 1.3, 3.4, 0xc8cdd1, 0, 2.0, 1.3);
    }

    if (type === "van") {
      box(group, width * 0.92, 0.85, 1.5, color, 0, 1.55, 0.65);
    }

    for (const x of [-width / 2, width / 2]) {
      for (const wheelZ of [-length * 0.32, length * 0.32]) {
        const wheel = cylinder(
          group, 0.3, 0.3, 0.15, 0x171717,
          x, 0.34, wheelZ
        );
        wheel.rotation.z = Math.PI / 2;
      }
    }

    const headMat = new THREE.MeshStandardMaterial({
      color: 0xfff2ba,
      emissive: 0xffbb66,
      emissiveIntensity: 0.5
    });

    box(
      group, 0.25, 0.15, 0.06, headMat,
      -width * 0.3, 0.72, -length / 2
    );
    box(
      group, 0.25, 0.15, 0.06, headMat,
      width * 0.3, 0.72, -length / 2
    );

    scene.add(group);
    group.position.set(roadCenter(z) + lane, 0, z);

    traffic.push({ mesh: group, lane, z, type, length });
  }

  function spawnTraffic() {
    const lanes = [-3.5, 0, 3.5];
    const lane = lanes[Math.floor(Math.random() * lanes.length)];

    const r = Math.random();
    const type = r < 0.2 ? "truck" : r < 0.45 ? "van" : "car";

    createVehicle(type, lane, -170 - Math.random() * 50);
  }

  function spawnCoin() {
    const lane = [-3.3, 0, 3.3][Math.floor(Math.random() * 3)];

    const mesh = new THREE.Mesh(
      new THREE.TorusGeometry(0.38, 0.12, 8, 18),
      new THREE.MeshStandardMaterial({
        color: 0xffd52a,
        metalness: 0.7,
        roughness: 0.2,
        emissive: 0x775000
      })
    );

    mesh.position.set(roadCenter(-160) + lane, 1.1, -160);
    scene.add(mesh);
    collectibles.push({ mesh, z: -160, lane });
  }

  // ---------------- UI AND GAME FLOW ----------------

  function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.style.display = "block";

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.style.display = "none";
    }, 1400);
  }

  function updateHUD() {
    $("level").textContent = level;
    $("speed").textContent = Math.round(speed * 3);
    $("coins").textContent = totalCoins;
    $("best").textContent =
      "LEVEL " + save.unlocked + " · " + totalCoins + " COINS";
  }

  function hideScreens() {
    menu.classList.add("hidden");
    garage.classList.add("hidden");
    result.classList.add("hidden");
  }

  function finishRace(won) {
    if (!running) return;

    running = false;
    crashed = !won;
    speed = 0;
    updateEngineSound();

    if (won) {
      const reward = 20 + level * 2 + runCoins;
      totalCoins += reward;
      save.coins = totalCoins;

      save.unlocked = Math.min(
        1000, Math.max(save.unlocked, level >= 1000 ? 1000 : level + 1)
      );

      $("resultTitle").textContent = "LEVEL COMPLETE! 🏁";
      $("resultText").textContent =
        "You earned " + reward + " coins! " +
        (level >= 1000 ? "You reached the final level!" :
          "Next level: " + (level + 1));

      playWinSound();
    } else {
      $("resultTitle").textContent = "CRASH! 💥";
      $("resultText").textContent =
        "You collected " + runCoins + " coins. Try again!";

      playLoseSound();
    }

    saveGame();
    updateHUD();
    result.classList.remove("hidden");
  }

  function startGame() {
    initAudio();
    hideScreens();
    clearTraffic();

    level = Math.min(1000, Math.max(1, save.unlocked));
    applyMap((level - 1) % maps.length);

    distance = 0;
    speed = 0;
    targetSpeed = 0;
    steer = 0;
    laneOffset = 0;
    runCoins = 0;
    spawnTimer = 0;
    coinTimer = 0;
    crashed = false;
    running = true;

    bike.position.set(roadCenter(4), 0, 4);
    bike.rotation.set(0, 0, 0);

    updateHUD();
    updateEngineSound();
  }

  $("start").addEventListener("click", startGame);
  $("retry").addEventListener("click", startGame);

  $("home").addEventListener("click", () => {
    running = false;
    crashed = false;
    result.classList.add("hidden");
    menu.classList.remove("hidden");
    updateEngineSound();
    updateHUD();
  });

  // ---------------- GARAGE: 80 MOTORCYCLES ----------------

  let previewIndex = save.selected;

  function bikeName(i) {
    const types = [
      "STREET", "RACING", "SPORT", "NINJA",
      "TURBO", "SHADOW", "FALCON", "PHANTOM"
    ];

    return types[Math.floor(i / 10)] + " " + (i + 1);
  }

  function bikePrice(i) {
    return i === 0 ? 0 : i * 50 + 100;
  }

  function bikeColor(i) {
    const colors = [
      0xff361e, 0x2196f3, 0x39d353, 0xffc107,
      0xb026ff, 0xffffff, 0x111111, 0xff55aa,
      0x00e5ff, 0xff7b00
    ];

    return colors[i % colors.length];
  }

  function updateGarage() {
    const owned = save.owned.includes(previewIndex);
    const selected = save.selected === previewIndex;

    $("bikeInfo").textContent = bikeName(previewIndex);
    $("bikePreview").style.color =
      "#" + bikeColor(previewIndex).toString(16).padStart(6, "0");

    $("bikePreview").textContent = "🏍️  #" + (previewIndex + 1);

    $("bikePrice").textContent = owned
      ? (selected ? "CURRENT MOTORCYCLE" : "OWNED")
      : "PRICE: " + bikePrice(previewIndex) + " COINS";

    $("buyBike").textContent = selected
      ? "SELECTED"
      : owned
        ? "SELECT BIKE"
        : "BUY FOR " + bikePrice(previewIndex);
  }

  $("garageBtn").addEventListener("click", () => {
    initAudio();
    menu.classList.add("hidden");
    garage.classList.remove("hidden");
    previewIndex = save.selected;
    updateGarage();
  });

  $("prevBike").addEventListener("click", () => {
    previewIndex = (previewIndex + 79) % 80;
    updateGarage();
  });

  $("nextBike").addEventListener("click", () => {
    previewIndex = (previewIndex + 1) % 80;
    updateGarage();
  });

  $("buyBike").addEventListener("click", () => {
    initAudio();

    if (save.owned.includes(previewIndex)) {
      save.selected = previewIndex;
      bikePaint = bikeColor(previewIndex);
      buildBike();
      saveGame();
      updateGarage();
      showToast("MOTORCYCLE SELECTED!");
      tone(650, 0.12, "triangle", 0.1);
      return;
    }

    const price = bikePrice(previewIndex);

    if (totalCoins < price) {
      showToast("NOT ENOUGH COINS!");
      tone(150, 0.2, "triangle", 0.12, -40);
      return;
    }

    totalCoins -= price;
    save.coins = totalCoins;
    save.owned.push(previewIndex);
    save.selected = previewIndex;
    bikePaint = bikeColor(previewIndex);

    buildBike();
    saveGame();
    updateHUD();
    updateGarage();

    showToast("BIKE PURCHASED!");
    playCoinSound();
  });

  $("back").addEventListener("click", () => {
    garage.classList.add("hidden");
    menu.classList.remove("hidden");
    updateHUD();
  });

  // ---------------- INPUT ----------------

  const keys = Object.create(null);

  window.addEventListener("keydown", e => {
    const key = e.key.toLowerCase();

    if ([
      "arrowleft", "arrowright", "arrowup", "arrowdown", " "
    ].includes(key)) {
      e.preventDefault();
    }

    keys[key] = true;
    initAudio();
  });

  window.addEventListener("keyup", e => {
    keys[e.key.toLowerCase()] = false;
  });

  window.addEventListener("blur", () => {
    for (const key in keys) keys[key] = false;
  });

  function bindHold(id, key) {
    const button = $(id);

    const down = e => {
      e.preventDefault();
      keys[key] = true;
      initAudio();
      try { button.setPointerCapture(e.pointerId); } catch (err) {}
    };

    const up = e => {
      e.preventDefault();
      keys[key] = false;
    };

    button.addEventListener("pointerdown", down);
    button.addEventListener("pointerup", up);
    button.addEventListener("pointerleave", up);
    button.addEventListener("pointercancel", up);
  }

  bindHold("left", "arrowleft");
  bindHold("right", "arrowright");
  bindHold("gas", "arrowup");
  bindHold("brake", "arrowdown");

  // ---------------- COLLISIONS ----------------

  function collisionCheck() {
    for (let i = traffic.length - 1; i >= 0; i--) {
      const t = traffic[i];

      if (Math.abs(t.z - bike.position.z) < t.length / 2 + 0.9) {
        if (Math.abs(t.mesh.position.x - bike.position.x) < 1.45) {
          finishRace(false);
          playCrashSound();
          return;
        }
      }
    }

    for (let i = collectibles.length - 1; i >= 0; i--) {
      const c = collectibles[i];

      if (
        Math.abs(c.z - bike.position.z) < 2 &&
        Math.abs(c.mesh.position.x - bike.position.x) < 1.6
      ) {
        scene.remove(c.mesh);
        collectibles.splice(i, 1);

        totalCoins++;
        runCoins++;
        save.coins = totalCoins;
        saveGame();

        updateHUD();
        playCoinSound();
        showToast("+1 COIN 🪙");
      }
    }
  }

  // ---------------- GAME LOOP ----------------

  function updateGame(dt) {
    if (!running) return;

    const gas = keys.arrowup || keys.w;
    const brake = keys.arrowdown || keys.s;
    const left = keys.arrowleft || keys.a;
    const right = keys.arrowright || keys.d;

    targetSpeed = gas ? 32 : 17;

    if (brake) {
      targetSpeed = 6;

      if (speed > targetSpeed + 3 &&
          performance.now() - lastBrakeSound > 700) {
        playBrakeSound();
        lastBrakeSound = performance.now();
      }
    }

    speed += (targetSpeed - speed) * Math.min(1, dt * 2.2);

    const steerDir = (right ? 1 : 0) - (left ? 1 : 0);
    steer += (steerDir - steer) * Math.min(1, dt * 8);

    laneOffset += steer * speed * dt * 0.22;
    laneOffset = THREE.MathUtils.clamp(laneOffset, -5.2, 5.2);

    bike.position.x = roadCenter(4) + laneOffset;
    bike.position.y = Math.sin(performance.now() * 0.009) * 0.025;
    bike.rotation.z = -steer * 0.22;
    bike.rotation.y = -steer * 0.08;

    distance += speed * dt;
    spawnTimer += dt;
    coinTimer += dt;

    if (spawnTimer > Math.max(0.85, 2 - level * 0.001)) {
      spawnTraffic();
      spawnTimer = 0;
    }

    if (coinTimer > 1.25) {
      spawnCoin();
      coinTimer = 0;
    }

    // Move traffic towards the motorcycle.
    for (let i = traffic.length - 1; i >= 0; i--) {
      const t = traffic[i];

      t.z += speed * dt * 1.15;
      t.mesh.position.z = t.z;
      t.mesh.position.x = roadCenter(t.z) + t.lane;

      if (t.z > 18) {
        scene.remove(t.mesh);
        traffic.splice(i, 1);
      }
    }

    // Move and rotate coins.
    for (let i = collectibles.length - 1; i >= 0; i--) {
      const c = collectibles[i];

      c.z += speed * dt * 1.15;
      c.mesh.position.z = c.z;
      c.mesh.position.x = roadCenter(c.z) + c.lane;
      c.mesh.rotation.y += dt * 3;

      if (c.z > 18) {
        scene.remove(c.mesh);
        collectibles.splice(i, 1);
      }
    }

    // Recycle the trees, buildings, rocks and scenery.
    for (const s of scenery) {
      s.z += speed * dt * 1.05;

      if (s.z > 28) {
        s.z = -315 - Math.random() * 20;
        s.side = Math.random() < 0.5 ? -1 : 1;
      }

      s.group.position.z = s.z;
      s.group.position.x =
        roadCenter(s.z) + s.side * (11 + Math.random() * 0.01);
    }

    collisionCheck();

    if (running && distance > 500 + level * 1.5) {
      finishRace(true);
    }

    updateEngineSound();
    updateHUD();
  }

  function animate(now) {
    requestAnimationFrame(animate);

    const dt = Math.min((now - (lastTime || now)) / 1000, 0.05);
    lastTime = now;

    updateGame(dt);

    // Third-person chase camera.
    const curveX = roadCenter(4);

    const desiredCamera = new THREE.Vector3(
      bike.position.x * 0.35 + curveX * 0.35,
      5.2,
      12.5
    );

    camera.position.lerp(desiredCamera, 0.08);
    camera.lookAt(
      bike.position.x * 0.3 + curveX * 0.3,
      1.2,
      -10
    );

    renderer.render(scene, camera);
  }

  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // ---------------- START ----------------

  applyMap(0);
  bikePaint = bikeColor(save.selected);
  buildBike();
  updateHUD();
  updateSoundButtons();

  camera.position.set(0, 5.2, 12.5);
  camera.lookAt(0, 1.2, -10);

  requestAnimationFrame(animate);
  loading.style.display = "none";
}